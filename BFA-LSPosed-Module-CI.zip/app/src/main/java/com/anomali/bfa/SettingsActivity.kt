package com.anomali.bfa
import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.*
class SettingsActivity: AppCompatActivity(){
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    supportFragmentManager.beginTransaction().replace(android.R.id.content, RootFragment()).commit()
  }
  class RootFragment: PreferenceFragmentCompat(){
    private val REQ_RINGTONE=1337
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
      preferenceManager.sharedPreferencesName="bfa_prefs"
      setPreferencesFromResource(R.xml.prefs, rootKey)
      findPreference<Preference>("ringtone")?.setOnPreferenceClickListener {
        val i=Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply{
          putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,"Select Alarm Ringtone")
          putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false)
          putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT,true)
          putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_ALARM)
          putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,BfaPrefs.getRingtone(requireContext()))
        }; startActivityForResult(i, REQ_RINGTONE); true
      }
    }
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?){
      super.onActivityResult(requestCode,resultCode,data)
      if(requestCode==REQ_RINGTONE && resultCode==Activity.RESULT_OK){
        val uri:Uri?=data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        BfaPrefs.setRingtone(requireContext(), uri)
        findPreference<Preference>("ringtone")?.summary = uri?.toString() ?: "Default"
      }
    }
  }
}
object BfaPrefs{
  fun getPrefs(ctx: android.content.Context)=ctx.getSharedPreferences("bfa_prefs", android.content.Context.MODE_PRIVATE)
  fun enabled(ctx: android.content.Context)=getPrefs(ctx).getBoolean("enable", true)
  fun targetLevel(ctx: android.content.Context)=getPrefs(ctx).getInt("level", 100)
  fun vibrateMs(ctx: android.content.Context)=getPrefs(ctx).getString("vibrate_ms","3000")!!.toLongOrNull()?:3000L
  fun getRingtone(ctx: android.content.Context): Uri? { val s=getPrefs(ctx).getString("ringtone_uri",null)?:return null; return Uri.parse(s) }
  fun setRingtone(ctx: android.content.Context, uri: Uri?){ getPrefs(ctx).edit().putString("ringtone_uri", uri?.toString()).apply() }
}
