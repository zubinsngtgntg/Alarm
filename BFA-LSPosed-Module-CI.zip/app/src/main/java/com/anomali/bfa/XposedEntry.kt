package com.anomali.bfa
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.*
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat
import de.robv.android.xposed.*
import de.robv.android.xposed.callbacks.XC_LoadPackage
class XposedEntry: IXposedHookLoadPackage{
  override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam){
    when(lpparam.packageName){
      "com.android.systemui","android"->hookBatteryAlarm(lpparam)
      "com.android.settings"->injectSettingsEntry(lpparam)
    }
  }
  private fun hookBatteryAlarm(lpparam: XC_LoadPackage.LoadPackageParam){
    XposedBridge.log("BFA: hookBatteryAlarm in "+lpparam.packageName)
    try{
      val appCtx=AndroidAppHelper.currentApplication().applicationContext
      val filter=IntentFilter(Intent.ACTION_BATTERY_CHANGED)
      val receiver=object: BroadcastReceiver(){
        var triggered=false
        override fun onReceive(context: Context, intent: Intent){
          val level=intent.getIntExtra("level",0)
          val status=intent.getIntExtra("status",1) // BatteryManager.BATTERY_STATUS_*
          val ctx=context.createPackageContext("com.anomali.bfa",0)
          val enabled=BfaPrefs.enabled(ctx)
          val target=BfaPrefs.targetLevel(ctx)
          val charging = status==2 || status==5
          if(!enabled){ triggered=false; return }
          if(charging && level>=target && !triggered){ triggered=true; fireAlarm(ctx, level) }
          else if(!charging || level<=target-3){ triggered=false }
        }
      }
      appCtx.registerReceiver(receiver, filter)
    }catch(t:Throwable){ XposedBridge.log("BFA: hookBatteryAlarm failed: "+t.message) }
  }
  private fun fireAlarm(ctx: Context, level:Int){
    try{
      val pm=ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
      val wl=pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,"BFA:Wakelock")
      wl.acquire(4000)
      val nm=ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val chId="bfa_channel"
      if(Build.VERSION.SDK_INT>=26){ nm.createNotificationChannel(NotificationChannel(chId,"Battery Full Alarm", NotificationManager.IMPORTANCE_HIGH)) }
      val noti=NotificationCompat.Builder(ctx,chId).setSmallIcon(android.R.drawable.ic_lock_idle_charging).setContentTitle("Battery Full").setContentText("Battery is "+level+"% — unplug the charger").setPriority(NotificationCompat.PRIORITY_HIGH).build()
      nm.notify(2025, noti)
      val vib=ctx.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
      val vms=BfaPrefs.vibrateMs(ctx)
      if(vms>0) vib.vibrate(vms)
      val uri=BfaPrefs.getRingtone(ctx)?:RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
      val rt:Ringtone=RingtoneManager.getRingtone(ctx, uri); rt.play()
    }catch(t:Throwable){ XposedBridge.log("BFA: fireAlarm error: "+t.message) }
  }
  private fun injectSettingsEntry(lpparam: XC_LoadPackage.LoadPackageParam){
    XposedBridge.log("BFA: injectSettingsEntry")
    fun tryHook(className:String, method:String){
      try{
        val cls=XposedHelpers.findClass(className, lpparam.classLoader)
        XposedBridge.hookAllMethods(cls, method, object: XC_MethodHook(){
          override fun afterHookedMethod(param: MethodHookParam){
            val fragment=param.thisObject
            val act=(fragment as android.app.Fragment).activity?:return
            val prefClass=XposedHelpers.findClass("androidx.preference.Preference", lpparam.classLoader)
            val screen=XposedHelpers.callMethod(fragment,"getPreferenceScreen")
            val pref=XposedHelpers.newInstance(prefClass, act)
            XposedHelpers.callMethod(pref,"setTitle","Battery Full Alarm")
            XposedHelpers.callMethod(pref,"setSummary","Configure target level & ringtone")
            XposedHelpers.callMethod(pref,"setOnPreferenceClickListener",
              android.preference.Preference.OnPreferenceClickListener{
                try{ val i=Intent(); i.setClassName("com.anomali.bfa","com.anomali.bfa.SettingsActivity"); act.startActivity(i) }catch(_:Throwable){}
                true
              })
            XposedHelpers.callMethod(screen,"addPreference", pref)
          }
        })
        XposedBridge.log("BFA: Hooked "+className+"."+method)
      }catch(_:Throwable){}
    }
    tryHook("com.android.settings.fuelgauge.PowerUsageSummary","onResume")
    tryHook("com.android.settings.fuelgauge.BatterySettings","onResume")
    tryHook("com.android.settings.battery.BatterySettings","onResume")
  }
}
